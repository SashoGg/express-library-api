require('dotenv').config();
const express = require('express');
const { createHash, randomBytes } = require('node:crypto');
const sqlite3 = require('sqlite3');
const { open } = require('sqlite');

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());

let db;
async function initializeDB() {
    db = await open({ filename: 'database.sqlite', driver: sqlite3.Database });
    await db.exec('PRAGMA foreign_keys = ON;');
    await db.exec(`CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password TEXT, salt TEXT)`);
    await db.exec(`CREATE TABLE IF NOT EXISTS students (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, grade TEXT)`);
}
initializeDB().catch(err => console.error(err));

// Helper function to hash passwords
const hashPassword = (password, salt) => createHash('sha256').update(password + salt).digest('hex');

let currentSessionUser = null; 

// --- AUTH ENDPOINTS ---

// NEW: Registration Route
app.post('/api/register', async (req, res) => {
    const { username, password } = req.body;
    try {
        const salt = randomBytes(16).toString('hex');
        const hashedPassword = hashPassword(password, salt);
        
        await db.run(
            'INSERT INTO users (username, password, salt) VALUES (?, ?, ?)',
            [username, hashedPassword, salt]
        );
        res.status(201).json({ message: "User created" });
    } catch (err) {
        if (err.message.includes("UNIQUE constraint failed")) {
            res.status(400).send("Username already exists");
        } else {
            res.status(500).send("Database error");
        }
    }
});

app.get('/api/is-logged', (req, res) => {
    if (currentSessionUser) {
        res.json({ username: currentSessionUser });
    } else {
        res.status(401).json({ message: "Not logged in" });
    }
});

app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    const user = await db.get('SELECT * FROM users WHERE username = ?', [username]);
    if (user && hashPassword(password, user.salt) === user.password) {
        currentSessionUser = user.username;
        return res.json({ username: user.username });
    }
    res.status(401).send("Invalid credentials");
});

app.post('/api/logout', (req, res) => {
    currentSessionUser = null;
    res.send("Logged out");
});

// --- STUDENT ENDPOINTS ---
app.get('/api/students', async (req, res) => {
    const students = await db.all('SELECT * FROM students');
    res.json(students);
});

app.get('/api/students/:id', async (req, res) => {
    const student = await db.get('SELECT * FROM students WHERE id = ?', [req.params.id]);
    res.json(student);
});

app.listen(port, () => console.log(`Server running at http://localhost:${port}`));