import { reactive } from 'vue';

export const store = reactive({
  username: null,

  // This function fetches the status and updates the store
  async fetchUser() {
    try {
      const res = await fetch('/api/is-logged');
      if (res.ok) {
        const data = await res.json();
        this.username = data.username;
      } else {
        this.username = null;
      }
    } catch (e) {
      this.username = null;
    }
  },

  // This function handles logout
  async logout() {
    await fetch('/api/logout', { method: 'POST' });
    this.username = null;
    // Redirect to home or login after logout
    window.location.href = "/";
  }
});