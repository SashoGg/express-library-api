<template>
  <div style="padding: 40px; max-width: 300px; margin: auto;">
    <h2>Register New User</h2>
    <form @submit.prevent="handleRegister">
      <input v-model="username" placeholder="Username" style="width: 100%; margin-bottom: 10px; padding: 8px;" required />
      <input v-model="password" type="password" placeholder="Password" style="width: 100%; margin-bottom: 10px; padding: 8px;" required />
      <button type="submit" style="width: 100%; padding: 10px; background: #3498db; color: white; border: none; cursor: pointer;">
        Register
      </button>
    </form>
    <p v-if="message" :style="{ color: isError ? 'red' : 'green' }">{{ message }}</p>
    <p><router-link to="/login">Already have an account? Login</router-link></p>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';

const username = ref('');
const password = ref('');
const message = ref('');
const isError = ref(false);
const router = useRouter();

const handleRegister = async () => {
  try {
    const res = await fetch('/api/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: username.value, password: password.value })
    });

    if (res.ok) {
      isError.value = false;
      message.value = "Registration successful! Redirecting to login...";
      setTimeout(() => router.push('/login'), 2000);
    } else {
      isError.value = true;
      message.value = await res.text();
    }
  } catch (e) {
    isError.value = true;
    message.value = "Server error!";
  }
};
</script>