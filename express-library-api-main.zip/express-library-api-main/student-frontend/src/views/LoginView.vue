<template>
  <div style="padding: 40px; max-width: 300px; margin: auto;">
    <h2>Login</h2>
    <form @submit.prevent="handleLogin">
      <input v-model="usernameInput" placeholder="Username" style="width: 100%; margin-bottom: 10px; padding: 8px;" required />
      <input v-model="passwordInput" type="password" placeholder="Password" style="width: 100%; margin-bottom: 10px; padding: 8px;" required />
      <button type="submit" style="width: 100%; padding: 10px; background: #42b983; color: white; border: none; cursor: pointer;">
        Login
      </button>
    </form>
    <p v-if="error" style="color: red;">{{ error }}</p>
    <p><router-link to="/register">Don't have an account? Register</router-link></p>
  </div>
</template>

<script setup>
import { ref, watch, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import { store } from '../store.js';

const usernameInput = ref('');
const passwordInput = ref('');
const error = ref('');
const router = useRouter();

// REQUIREMENT: Use watch to redirect if username exists
watch(() => store.username, (newUsername) => {
  if (newUsername) {
    router.push('/');
  }
});

// Check if already logged in when arriving
onMounted(() => {
  if (store.username) {
    router.push('/');
  }
});

const handleLogin = async () => {
  const res = await fetch('/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: usernameInput.value, password: passwordInput.value })
  });

  if (res.ok) {
    // Update the store so the 'watch' triggers
    await store.fetchUser();
  } else {
    error.value = "Login failed! Check your credentials.";
  }
};
</script>