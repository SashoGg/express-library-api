<template>
  <div style="padding: 20px; font-family: sans-serif;">
    <h2>Student Registry</h2>

    <div style="background: #f9f9f9; padding: 15px; border-radius: 8px; margin-bottom: 30px; border: 1px solid #ddd;">
      <h3>Add New Student</h3>
      <form @submit.prevent="addStudent" style="display: flex; gap: 10px;">
        <input v-model="newName" placeholder="Enter Name" required style="padding: 8px;" />
        <input v-model="newGrade" placeholder="Enter Grade" required style="padding: 8px;" />
        <button type="submit" style="padding: 8px 15px; background-color: #42b983; color: white; border: none; cursor: pointer;">
          Add Student
        </button>
      </form>
    </div>

    <table border="1" style="width: 100%; border-collapse: collapse;">
      <thead>
        <tr style="background-color: #eee; text-align: left;">
          <th style="padding: 10px;">ID</th>
          <th style="padding: 10px;">Name</th>
          <th style="padding: 10px;">Grade</th>
          <th style="padding: 10px;">Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="student in students" :key="student.id">
          <td style="padding: 10px;">{{ student.id }}</td>
          <td style="padding: 10px;">{{ student.name }}</td>
          <td style="padding: 10px;">{{ student.grade }}</td>
          <td style="padding: 10px; display: flex; gap: 10px;">
            <router-link :to="'/student/' + student.id">View</router-link>
            <button @click="deleteStudent(student.id)" style="color: white; background: #ff4d4d; border: none; padding: 5px 10px; cursor: pointer; border-radius: 4px;">
              Delete
            </button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';

const students = ref([]);
const newName = ref('');
const newGrade = ref('');

const fetchStudents = async () => {
  try {
    // UPDATED: Now using the proxy path
    const response = await fetch('/api/students');
    students.value = await response.json();
  } catch (error) {
    console.error("Fetch error:", error);
  }
};

const addStudent = async () => {
  try {
    const response = await fetch('/api/students', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: newName.value, grade: newGrade.value })
    });
    if (response.ok) {
      newName.value = '';
      newGrade.value = '';
      await fetchStudents();
    }
  } catch (error) {
    console.error("Add error:", error);
  }
};

const deleteStudent = async (id) => {
  if (confirm("Are you sure?")) {
    try {
      const response = await fetch(`/api/students/${id}`, { method: 'DELETE' });
      if (response.ok) await fetchStudents();
    } catch (error) {
      console.error("Delete error:", error);
    }
  }
};

onMounted(fetchStudents);
</script>