import { createRouter, createWebHistory } from 'vue-router';
import HomeView from './views/HomeView.vue';
import DetailsView from './views/DetailsView.vue';
import LoginView from './views/LoginView.vue';
import RegisterView from './views/RegisterView.vue'; // Import Register

const routes = [
  { path: '/', component: HomeView },
  { path: '/login', component: LoginView },
  { path: '/register', component: RegisterView }, // Add Route
  { path: '/student/:id', component: DetailsView }
];

const router = createRouter({
  history: createWebHistory(),
  routes
});

export default router;